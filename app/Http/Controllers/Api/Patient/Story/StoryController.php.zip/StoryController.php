<?php
/**
 *
 * @category zStarter
 *
 * @ref zCURD
 * @author  Defenzelite <hq@defenzelite.com>
 * @license https://www.defenzelite.com Defenzelite Private Limited
 * @version <zStarter: 1.1.0>
 * @link    https://www.defenzelite.com
 */

namespace App\Http\Controllers\Api\patient\story;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Models\UserSubscription;
use App\Models\Story;
use Auth;

class StoryController extends Controller
{
    protected $now;
    private $resultLimit = 10;

    public function __construct()
    {
        $this->now = \Carbon\Carbon::now();
    }

    public function storyIndex(Request $request)
    {
        // return 's';
        try {
            $page = $request->has('page') ? $request->get('page') : 1;
            $limit = $request->has('limit') ? $request->get('limit') : $this->resultLimit;

            $stories = Story::query();
            if ($request->has('from') && $request->has('to') && $request->get('from') && $request->get('to')) {
                $stories->whereBetween('created_at', [$request->get('from'), $request->get('to')]);
            }

            $stories = $stories->with(['user' => function ($q) {
                $q->select('id', 'gender', 'first_name', 'phone', 'avatar', 'dob');
            }, 'createdBy' => function ($q) {
                $q->select('id', 'first_name');
            }])->where('user_id', auth()->id())->where('type', 1)->latest()->limit($limit)
                ->offset(($page - 1) * $limit)->first();
            if ($stories) {

                $stories['detail'] = json_decode($stories['detail']);
                $stories['chart'] = json_decode($stories['chart']);

                return $this->success($stories);
            }
            return $this->success([]);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function mySummaryIndex(Request $request)
    {
        try {
            $page = $request->has('page') ? $request->get('page') : 1;
            $limit = $request->has('limit') ? $request->get('limit') : $this->resultLimit;

            $stories = Story::select('id', 'user_id', 'date', 'name', 'age', 'dob', 'detail', 'is_organize', 'type', 'created_at')->with(['user' => function ($q) {
                $q->select('id', 'gender', 'first_name', 'phone', 'avatar', 'dob');
            }])->where('user_id', auth()->id())->latest()->limit($limit)
                ->offset(($page - 1) * $limit)->first();
            if ($stories) $stories['detail'] = json_decode($stories['detail']);
            return $this->success($stories);

        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function myJourneyIndex(Request $request)
    {
        try {
            $stories = Story::where('user_id', auth()->id())->where('type', 1)->latest()->first();
            return $this->success($stories);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function myBloodReport(Request $request)
    {
        try {
            $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', auth()->id())->where('type', 1)->latest()->first();
            $charts = json_decode($stories['chart']);
            $stories['blood'] = $charts->blood;
            return $this->success($charts->blood);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function myChartIndex(Request $request)
    {
        try {
            $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', auth()->id())->where('type', 1)->latest()->first();
            if ($stories) $stories['chart'] = json_decode($stories['chart']);
            return $this->success($stories);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function myInsite(Request $request, $id = null)
    {
        try {
            $year = now()->format('Y');
            if ($id == null) {
                $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', auth()->id())->where('type', 1)->latest()->first();
            } else {
                $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', $id)->where('type', 1)->latest()->first();
            }
            if ($stories) {
                $stories['chart'] = json_decode($stories['chart']);
                $insights = [];

                foreach ($stories['chart'] as $key => $value) {
                    $insights[$key]['Jan'] = 0;
                    $insights[$key]['Feb'] = 0;
                    $insights[$key]['Mar'] = 0;
                    $insights[$key]['Apr'] = 0;
                    $insights[$key]['May'] = 0;
                    $insights[$key]['Jun'] = 0;
                    $insights[$key]['Jul'] = 0;
                    $insights[$key]['Aug'] = 0;
                    $insights[$key]['Sep'] = 0;
                    $insights[$key]['Oct'] = 0;
                    $insights[$key]['Nov'] = 0;
                    $insights[$key]['Dec'] = 0;
                }

                foreach ($stories['chart'] as $key => $value) {
                    foreach ($value as $child_value) {
                        if (isset($child_value->date) && \Carbon\Carbon::parse($child_value->date)->format('Y') == $year) {
                            $m = \Carbon\Carbon::parse($child_value->date)->format('M');
                            $insights[$key][$m] += 1;
                        }
                    }

                }

                return $this->success($insights);
            } else {
                return $this->errorOk('Chart data is not found!');
            }
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function insiteChart(Request $request, $id = null)
    {
        try {
            $year = now()->format('Y');
            if ($id != null) {
                $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', $id)->where('type', 1)->latest()->first();
            } else {
                $stories = Story::select('id', 'user_id', 'chart', 'type')->where('user_id', auth()->id())->where('type', 1)->latest()->first();
            }
            if ($stories) {
                $chartBlood = $stories['chart'] != null ? json_decode($stories['chart'])->blood : null;
                $chartLiver = $stories['chart'] != null ?  json_decode($stories['chart'])->liver : null;
                $chartKidney = $stories['chart'] != null ? json_decode($stories['chart'])->kidney : null;
                $chartLipid = $stories['chart'] != null ? json_decode($stories['chart'])->lipid : null;
                $chartThyroid = $stories['chart'] != null ? json_decode($stories['chart'])->thyroid : null;
                $chartDiabetes = $stories['chart'] != null ? json_decode($stories['chart'])->diabetes : null;
                $chartUrineTest = $stories['chart'] != null ? json_decode($stories['chart'])->urineTest : null;
                $blood = [];
                $liver = [];
                $kidney = [];
                $lipid = [];
                $thyroid = [];
                $diabetes = [];
                $urineTest = [];
                $chart = null;

                $monthNames = [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Oct',
                    'Nov',
                    'Dec',
                ];
                
                
                
                // $monthNames = [];
                // foreach ($mNames as $index => $mName) {
                //     if($index + 1 <= \Carbon\Carbon::now()->format('m')){
                //         $monthNames[] = $mName;
                //     }
                // }

                $d = [];
                if ($chartBlood != null) {
                    foreach ($chartBlood as $i => $bloodItems) {
                        if ($bloodItems->date == null || trim($bloodItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedBloodItem = collect($chartBlood)->filter(function ($data) use ($key, $monthName) {
                                return (int)explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($bloodItems as $j => $bloodItem) {
                                // return $j;
                                if ($j != 'date' && $datedBloodItem != null) {
                                    $blood[$j][$monthName] = $datedBloodItem->{$j};
                                    // $values[$monthName] = $datedBloodItem->{$j};
                                    // $blood[] = ["name" => $j, 'items' => $values];
                                } else {
                                    $blood[$j][$monthName] = 0;
                                    // $values[$monthName] = 0;
                                    // $blood[] = ["name" => $j, 'items' => $values];
                                }
                            }
                        }

                    }
                    $bloodData = [];
                    foreach ($blood as $key => $val) {
                        if ($key !== 'date') {
                            $bloodData[$key] = $val;
                        }
                    }
                    $bloodData = count($bloodData) <= 0 ? null : $bloodData;
                    $chart[] = ['name' => 'blood', 'items' => $bloodData];
                }
                if ($chartLiver != null) {
                    foreach ($chartLiver as $i => $liverItems) {
                        if ($liverItems->date == null || trim($liverItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedLiverItem = collect($chartLiver)->filter(function ($data) use ($key, $monthName) {
                                // return $data;

                                return explode('-', $data->date ?? now())[1] == $key + 1;
                            })->first();

                            foreach ($liverItems as $j => $liverItem) {
                                if ($j != 'date' && $datedLiverItem != null) {
                                    if (!isset($datedLiverItem->{$j})) {
                                        $datedLiverItem->{$j} = null;
                                    }
                                    $liver[$j][$monthName] = $datedLiverItem->{$j};
                                } else {
                                    $liver[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $liverData = [];
                    foreach ($liver as $key => $val) {
                        if ($key !== 'date') {
                            $liverData[$key] = $val;
                        }
                    }
                    $liverData = count($liverData) <= 0 ? null : $liverData;
                    $chart[] = ['name' => 'liver', 'items' => $liverData];
                }

                if ($chartKidney != null) {
                    foreach ($chartKidney as $i => $kidneyItems) {
                        if ($kidneyItems->date == null || trim($kidneyItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedKidneyItem = collect($chartKidney)->filter(function ($data) use ($key, $monthName) {
                                return explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($kidneyItems as $j => $kidneyItem) {
                                if ($j != 'date' && $datedKidneyItem != null) {
                                    $kidney[$j][$monthName] = $datedKidneyItem->{$j};
                                } else {
                                    $kidney[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $kidneyData = [];
                    foreach ($kidney as $key => $val) {
                        if ($key !== 'date') {
                            $kidneyData[$key] = $val;
                        }
                    }
                    $kidneyData = count($kidneyData) <= 0 ? null : $kidneyData;
                    $chart[] = ['name' => 'kidney', 'items' => $kidneyData];
                }

                if ($chartLipid != null) {

                    foreach ($chartLipid as $i => $lipidItems) {
                        if ($lipidItems->date == null || trim($lipidItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedLipidItem = collect($chartLipid)->filter(function ($data) use ($key, $monthName) {
                                return explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($lipidItems as $j => $lipidItem) {
                                if ($j != 'date' && $datedLipidItem != null) {
                                    $lipid[$j][$monthName] = $datedLipidItem->{$j};
                                } else {
                                    $lipid[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $lipidData = [];
                    foreach ($lipid as $key => $val) {
                        if ($key !== 'date') {
                            $lipidData[$key] = $val;
                        }
                    }
                    $lipidData = count($lipidData) <= 0 ? null : $lipidData;
                    $chart[] = ['name' => 'lipid', 'items' => $lipidData];
                }
                if ($chartThyroid != null) {

                    foreach ($chartThyroid as $i => $thyroidItems) {
                        if ($thyroidItems->date == null || trim($thyroidItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedthyroidItem = collect($chartThyroid)->filter(function ($data) use ($key, $monthName) {
                                return explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($thyroidItems as $j => $thyroidItem) {
                                if ($j != 'date' && $datedthyroidItem != null) {
                                    $thyroid[$j][$monthName] = $datedthyroidItem->{$j};
                                } else {
                                    $thyroid[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $thyroidData = [];
                    foreach ($thyroid as $key => $val) {
                        if ($key !== 'date') {
                            $thyroidData[$key] = $val;
                        }
                    }
                    $thyroidData = count($thyroidData) <= 0 ? null : $thyroidData;
                    $chart[] = ['name' => 'thyroid', 'items' => $thyroidData];
                }

                if ($chartDiabetes != null) {
                    foreach ($chartDiabetes as $i => $diabetesItems) {
                        if ($diabetesItems->date == null || trim($diabetesItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedDiabetesItem = collect($chartDiabetes)->filter(function ($data) use ($key, $monthName) {
                                return $data->date != null && explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($diabetesItems as $j => $diabetesItem) {
                                if ($j != 'date' && $datedDiabetesItem != null) {
                                    $diabetes[$j][$monthName] = $datedDiabetesItem->{$j};
                                } else {
                                    $diabetes[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $diabetesData = [];
                    foreach ($diabetes as $key => $val) {
                        if ($key !== 'date') {
                            $diabetesData[$key] = $val;
                        }
                    }
                    $diabetesData = count($diabetesData) <= 0 ? null : $diabetesData;
                    $chart[] = ['name' => 'diabetes', 'items' => $diabetesData];
                }

                if ($chartUrineTest != null) {
                    foreach ($chartUrineTest as $i => $urineTestItems) {
                        if ($urineTestItems->date == null || trim($urineTestItems->date) == '') {
                            continue;
                        }
                        foreach ($monthNames as $key => $monthName) {
                            $datedUrineTestItem = collect($chartUrineTest)->filter(function ($data) use ($key, $monthName) {
                                return explode('-', $data->date)[1] == $key + 1;
                            })->first();
                            foreach ($urineTestItems as $j => $urineTestItem) {
                                if ($j != 'date' && $datedUrineTestItem != null) {
                                    $urineTest[$j][$monthName] = $datedUrineTestItem->{$j};
                                } else {
                                    $urineTest[$j][$monthName] = 0;
                                }
                            }
                        }

                    }
                    $urineTestData = [];
                    foreach ($urineTest as $key => $val) {
                        if ($key !== 'date') {
                            $urineTestData[$key] = $val;
                        }
                    }
                    $urineTestData = count($urineTestData) <= 0 ? null : $urineTestData;
                    $chart[] = ['name' => 'urineTest', 'items' => $urineTestData];
                }

                return $this->success(['has_story' => $stories != null, 'chart' => $chart]);
            } else {
                return $this->success([]);
            }
        } catch (\Exception | \Error $e) {
            return $this->error("Sorry! Failed to data! " . $e);
        }
    }


    public function storyOrganizeRequest(Request $request)
    {
        // return 's';
        // $this->validate($request, [
        //     'user_id' => 'required',
        // ]);
        try {
            //response
            $storyRecord = Story::where('user_id', auth()->id())->where('type', 1)->first();  //LIVE
            $storyDev = Story::where('user_id', auth()->id())->where('type', 0)->first(); // DEV
            //check user subscription
            $userSubs = UserSubscription::where('user_id', auth()->id());
            //    if($user){
            if ($userSubs->latest()->exists()) {
                if ($userSubs->where('to_date', '>=', now())->latest()->first()) {
                    if (!$storyRecord) {
                        Story::create([
                            'user_id' => auth()->id(),
                            'date' => now(),
                            'status' => 0,
                            'type' => 0,
                            'is_organize' => 0,
                        ]);
                        Story::create([
                            'user_id' => auth()->id(),
                            'date' => now(),
                            'status' => 2,
                            'type' => 1,
                            'is_organize' => 0,
                        ]);
                        return $this->successMessage('Story Created succesfully!');
                    } else {
                        $storyDev->update([
                            'is_organize' => 0,
                        ]);
                        return $this->successMessage('Story Is Organize Updated succesfully!');
                    }
                } else {
                    return $this->errorOk('Your subscription has expired, please buy a new one!');
                }
            } else {
                return $this->errorOk('You don\'t have subscription to organize your report!');
            }
            //    }else{
            //        return $this->errorOk('This User is does\'t exists!');
            //    }
        } catch (\Exception | \Error $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function patientSummaryIndex(Request $request, $id)
    {
        try {
            $page = $request->has('page') ? $request->get('page') : 1;
            $limit = $request->has('limit') ? $request->get('limit') : $this->resultLimit;

            $stories = Story::select('id', 'user_id', 'date', 'name', 'age', 'dob', 'detail', 'is_organize', 'type', 'created_at')->with(['user' => function ($q) {
                $q->select('id', 'gender', 'first_name', 'phone', 'avatar', 'dob');
            }])->where('user_id', $id)->where('type', 1)->latest()->first();
            if ($stories) {
                $stories['detail'] = json_decode($stories['detail']);
                return $this->success($stories);
            } else {
                return $this->success([]);
            }

        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function patientJourneyIndex(Request $request, $id)
    {
        try {
            $stories = Story::select('id', 'user_id', 'journey')->where('user_id', $id)->where('type', 1)->latest()->first();
            return $this->success($stories);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

    public function patientChartIndex(Request $request, $id)
    {
        try {
            $stories = Story::select('id', 'user_id', 'chart')->where('user_id', $id)->where('type', 1)->latest()->first();
            if ($stories) $stories['chart'] = json_decode($stories['chart']);
            return $this->success($stories);
        } catch (\Exception $e) {
            return $this->error("Sorry! Failed to data! " . $e->getMessage());
        }
    }

}


