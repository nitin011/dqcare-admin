<?php

return [
    'api_key' => 'rzp_test_N1xH3RiCKKmOJf',
    'api_secret' => 'DXJxjGZlri3g1crsqxamgOQg'
];